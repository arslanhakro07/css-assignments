<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>web page</title>
    <link rel="stylesheet" href="webbyown.css">
</head>
<body>
    <div id="navbar">
      <a href="home">Home</a>
      <a href="news">News</a>
      <a href="contact">Contact</a>
      <a href="about">About us</a>
    </div>
    <h1 align="center">Order something delicious</h1>

   

      

        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>

        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>

        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>

        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>
    </div>
    <br>

    <div class="row">
    <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>
        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>
        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>
        <div class="col-2" id="items">
            <img src="https://images.unsplash.com/photo-1508736793122-f516e3ba5569?q=80&w=1286&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="195px">
       <h3>Burger</h3>
       <h3>price 10$</h3>
        </div>
       
    </div>

    <div class="row">
        <div class="para">

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt voluptates officia consectetur aut exercitationem aliquid mollitia quisquam nemo placeat quibusdam sapiente, sed deleniti inventore dicta quam modi itaque reprehenderit illum, illo ipsum est commodi ea adipisci? Culpa recusandae accusantium veniam, tempore similique cupiditate hic minus cum atque perspiciatis eveniet laudantium beatae quaerat dolore provident, maxime officiis fugiat eius temporibus. A ducimus quidem, recusandae possimus sit dolore laboriosam quisquam nulla provident, illum, corporis rem? Dolores vero natus officia ratione fugiat iusto nihil provident, obcaecati sequi nisi repellat soluta itaque mollitia voluptate magnam quos illo? Maiores earum accusamus et adipisci totam, eum qui quam exercitationem laudantium harum consectetur nulla cupiditate possimus quod! Quasi molestiae, dolore quia magni consequuntur dolor modi tenetur quibusdam beatae dolorum veniam odit asperiores nemo corrupti sunt quaerat neque error quidem, distinctio doloribus cumque animi fugit assumenda quae! Dolor quia debitis, reiciendis, temporibus iure alias facere laboriosam ratione magni, iusto quaerat quam ipsa? Consectetur quis maiores quas ea sit quasi. Doloremque earum cupiditate voluptate temporibus itaque nemo quos accusantium. Explicabo quasi cum qui excepturi quos. Veritatis iusto harum obcaecati ipsam. Nam excepturi distinctio culpa perferendis magnam hic provident eveniet possimus quaerat quasi, a harum illum facilis similique mollitia deleniti nihil nesciunt ipsam minima? Dolorem ullam modi sint iusto. Dolore officia ipsam nostrum dicta? Quas nostrum doloribus adipisci quo quisquam fugiat laborum modi temporibus quasi ratione. Exercitationem, laudantium vero? Eligendi nobis sed sunt minima vel modi obcaecati. Porro non quasi incidunt natus qui! Voluptatibus vel a laboriosam aliquam voluptates quasi ratione, ipsam nulla autem qui, nisi dolores fugit minima aspernatur eius labore illo tenetur eligendi temporibus. Sequi magnam impedit repellendus reprehenderit culpa maxime distinctio dolorum qui optio recusandae necessitatibus architecto, fuga unde. Quos, minus vero maxime maiores dolorem quae vel saepe, quia necessitatibus doloremque facere. Magnam minus id illo aliquid placeat, provident ad voluptate aperiam accusamus suscipit, laudantium repudiandae iste molestiae quod culpa cumque exercitationem. Quaerat eaque impedit placeat quo dolorem assumenda ducimus culpa expedita magnam dignissimos sint dolores quidem sit eos voluptatum alias itaque totam aut, quam, ratione rem nulla molestias numquam soluta! Error perferendis enim debitis cum quo odit iste reiciendis nobis deserunt totam. Quaerat corrupti, incidunt dolores in illo unde? Praesentium placeat, nobis provident expedita blanditiis laudantium dolorem commodi ut veniam tenetur velit! Asperiores obcaecati quo non vel corporis veniam sapiente eligendi. Voluptate, incidunt! Nihil amet similique commodi nesciunt harum porro fugiat dicta blanditiis delectus voluptas? In?</p>
        </div>
    </div>

    <div class="row" >
        <div class="col-12" id="footer">
       
      <p>@copyrightwebbyownchoice2024</p>
   

        </div>
    </div>


</body>
</html>