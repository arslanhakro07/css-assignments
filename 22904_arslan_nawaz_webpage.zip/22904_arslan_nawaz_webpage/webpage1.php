<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>web page 1</title>
    <link rel="stylesheet" href="webpage.css">
</head>
<body>
    <div class="row" >

      <div class="col-12" id="navbar">

        <div id="anchors">

        <a href="feedback">feedback</a>
        <a href="login">login</a></div>
      <div id="login"> <p>LOGO Here</p></div>
    </div>
    </div>

    <h1 align="center">Services</h1>

    <div class="row">

 <div class="col-4" id="services">

<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
<div class="col-4">
<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
<div class="col-4">
<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
</div>


<h1 align="center">Product</h1>

<div class="row">

<div class="col-4" id="products">

<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
<div class="col-4">
<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
<div class="col-4">
<img src="https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="" width="300px">

</div>
</div>




<div class="footer">

<div class="row" id="ending">


<div class="col-4" >

<div id="company">
<h1>Company</h1>
<h3>products</h3>
<h3>vendor</h3>
<h3>shipping</h3>
</div>
</div>




<div class="col-4" >

<div id="service">
<h1>services</h1>
<h3>products</h3>
<h3>qualitity</h3>
<h3>shipping</h3>
</div>
</div>



<div class="col-4" >

<div id="contact">
<h1>Contact</h1>
<h3>address here</h3>
<h3>phone no</h3>
<h3>facebook link</h3>
</div>
</div>





</div>

</div>

</body>
</html>