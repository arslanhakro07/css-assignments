<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>layout 2</title>
    <link rel="stylesheet" href="layout_2.css">
</head>
<body>
    <div class="row" id="sitename">
        
            <div class="col-12">
                <h1>Easyfood.com</h1>
            </div>
        </div>
    
  
        <div class="row">
        <div class="col-12"  id="navbar">
            <a href="link">link</a>
            <a href="link">link</a>
            <a href="link">link</a>
            <a href="link">link</a>
            <a href="link">link</a>
            <a href="link">link</a>
            
        </div>
    </div>


    <div class="row">

    <div class="col-10" id="para">
        <h1>Heading</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab quam ipsam minus voluptatum dolorem excepturi, pariatur rem dicta facilis numquam facere, nostrum, accusantium magni. Vero ullam, debitis aliquam quidem labore minus autem, possimus unde adipisci deserunt dignissimos non, amet molestiae! Sint similique vitae, mollitia consequuntur dolorem ullam quos modi fugit fuga. Nihil maiores ratione dolores porro blanditiis dignissimos culpa non deserunt mollitia aut repellendus quidem, tempore laborum officiis temporibus ad corrupti quia animi fugiat cupiditate consequuntur quae dolorum. Officia, unde vel ducimus voluptatibus adipisci sequi dolor nam laboriosam consequatur in esse, voluptate quod distinctio voluptates inventore quia tempore soluta voluptatum deserunt facere pariatur. Aliquid earum quod, tenetur dolore voluptatum maiores hic quasi deleniti voluptatem saepe veritatis unde blanditiis voluptatibus tempora quisquam repellendus, veniam porro consequuntur alias quibusdam labore exercitationem. Libero ut debitis alias, saepe ea animi perspiciatis, dolores architecto, accusantium culpa itaque autem unde quibusdam odit est eos nobis. Eligendi natus officiis ullam cumque fugiat error, ipsam tenetur velit iste sunt alias aliquid aliquam voluptatum qui, ex ut, cupiditate consequuntur provident nisi repellendus? Fugiat cum quia porro assumenda voluptatibus laborum sint at ratione, dignissimos consectetur pariatur odit libero consequuntur. Omnis error obcaecati, consequatur officia numquam delectus illo explicabo nesciunt illum!
        Lorem ipsum dolor sit,<br><br> amet consectetur adipisicing elit. Tempore deserunt eos necessitatibus a dolorem qui autem. Id quisquam laboriosam at molestias fugit amet iusto, nostrum magnam provident nisi earum placeat ipsum ipsam asperiores repudiandae atque animi saepe excepturi vel aliquid non vero minus? Deserunt dolores ducimus voluptatem libero veritatis iure, provident, sit quam, eum dicta odit obcaecati voluptatibus corporis doloribus beatae eos recusandae fuga vero quidem. Voluptas vel quam dolorem animi delectus cupiditate fuga maiores aut beatae, asperiores quas, quasi repellendus consequatur ipsam eaque consectetur. Alias quidem unde vitae? Voluptatum odit atque accusantium! Ipsa quae provident cupiditate libero modi vitae.
       Lorem ipsum dolor sit amet,<br><br> consectetur adipisicing elit. Qui natus eos ea cupiditate, nobis aspernatur beatae reprehenderit necessitatibus, totam, voluptatum voluptatem adipisci vero quidem commodi nostrum delectus. Optio unde perferendis totam dolorum est autem commodi numquam iusto reprehenderit quibusdam vitae nihil debitis aperiam molestias consectetur illum, excepturi facilis nobis modi earum praesentium dolore. Autem fugiat eos est expedita tempore veniam? Molestias explicabo architecto cumque obcaecati non quam impedit minus maxime, sit debitis, quos incidunt harum! Dolore laborum similique quae possimus labore nisi facere quaerat, tenetur magnam est mollitia deleniti a, modi non iure error dolorem amet! Autem culpa libero nihil.
    </p>
    </div>
    <div class="col-2" id="list">
        <ul>
            <h2>Block Header</h2>
        <li>item 1</li>
        <li>item 2</li>
        <li>item 3</li>
        <li>item 4</li>
        <li>item 5</li>
        <li>item 6</li>
        <li>item 7</li>
        <li>item 8</li>
        <li>item 9</li>
        <li>item 10</li>
    <br></ul>
    </div>

    </div>
      <div class="row">
        <div class="col-12" id="footer">
            <p>@copywrighteasyfood.com2024</p>

        </div>
      </div>  


</body> 
</html>