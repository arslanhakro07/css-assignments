<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Css Selectors Layout</title>
    <link rel="stylesheet" href="selectors_layout.css">
</head>
<body>
    <div class="row">
        <div class="col-12 " align="center"><h1>Image here</h1></div>
    </div>
    <div class="row" >
        <div class="col-3 " id="first_box">
            <div id="first_inner">
                <h2>Menue</h2>
                <h3>here</h3>
            </div>
            <div id="first_inner2">
                <h2>some</h2>
                <h3>content</h3>
                <h3>here</h3>
            </div>

        </div>


        <div class="col-6 "  id="sec_box">
        <div id="sec1_inner"><h2>simple menue here</h2></div>
        <div id="secinners">
           
    <div id="sec_inner">
                 <h2>some</h2>
                <h3>content</h3>
                <h3>here</h3>
    </div>
    <div id="sec_inner">
                 <h2>some</h2>
                <h3>content</h3>
                <h3>here</h3>
    </div>

    </div>
<h3 align="center">some content here</h3>

    </div>
        <div class="col-3 "  id="third_box">

        <div id="third_inner">
                <h1>login form</h1>
                <div id="inputs">
                    <h4>username</h4>
                </div>
                <div id="inputs">
                    <h4>password</h4>
                </div>

                <div id="input_btn">
                    <h5>submit</h5>
                </div>

            </div>
            <div id="third_inner2">
                <h2>some</h2>
                <h3>content</h3>
                <h3>here</h3>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12" align="center">
            <h1>footer @copywright here</h1>

        </div>
    </div>
</body>
</html>